#ifndef STUDENTANY_H
#define STUDENTANY_H

struct student {

std::string name;
int id;

double midt, fin, assig;

};

#end