#ifndef UNIVERSITY_H
#define UNIVERSITY_H

class University {

Student *stud;
std::string name;

public:
//Default Constructor
University(std::string name, Student *stud): name(name), stud(stud) {}

//Alt Constructor
University(Student *stud=NULL): name("Strathmore University"), stud(stud) {}


std::string getAllStudents(){return stud->getName();}
std::string getUniversityName(){return name;}

};

#endif