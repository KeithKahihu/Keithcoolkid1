#ifndef PARENT_H
#define PARENT_H

class Parent {
public:
	virtual const char * getName(){ return "Parent"; }

};

#endif